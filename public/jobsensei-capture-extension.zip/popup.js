const DEFAULT_APP_URL = 'https://jobsensei.app/#applications'
const PENDING_SELECTION_KEY = 'jobsensei_pending_selection_capture_v1'
const PREFS_KEY = 'jobsensei_extension_prefs_v1'
const SEARCH_PARAMS = new URLSearchParams(window.location.search)
const SURFACE = SEARCH_PARAMS.get('surface') === 'sidepanel' ? 'sidepanel' : 'popup'
const SIDEPANEL_TAB_ID = Number.parseInt(SEARCH_PARAMS.get('tabId') || '', 10) || null
const SIDEPANEL_WINDOW_ID = Number.parseInt(SEARCH_PARAMS.get('windowId') || '', 10) || null
const DEFAULT_PREFS = { theme: 'dark', visuals: false, language: 'en', languageChosen: false }
const THEME_ORDER = ['dark', 'daylight', 'myspace']
const THEME_META = {
  dark: {
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path></svg>',
  },
  daylight: {
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2"></path><path d="M12 20v2"></path><path d="m4.93 4.93 1.41 1.41"></path><path d="m17.66 17.66 1.41 1.41"></path><path d="M2 12h2"></path><path d="M20 12h2"></path><path d="m6.34 17.66-1.41 1.41"></path><path d="m19.07 4.93-1.41 1.41"></path></svg>',
  },
  myspace: {
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.93 2.74c.24-.99 1.9-.99 2.14 0l.52 2.14a3.4 3.4 0 0 0 2.53 2.53l2.14.52c.99.24.99 1.9 0 2.14l-2.14.52a3.4 3.4 0 0 0-2.53 2.53l-.52 2.14c-.24.99-1.9.99-2.14 0l-.52-2.14a3.4 3.4 0 0 0-2.53-2.53l-2.14-.52c-.99-.24-.99-1.9 0-2.14l2.14-.52a3.4 3.4 0 0 0 2.53-2.53l.52-2.14Z"></path><path d="M20 15v4"></path><path d="M22 17h-4"></path></svg>',
  },
}
const LANGUAGE_OPTIONS = window.JobSenseiExtensionI18n?.languages || [{ code: 'en', label: 'English', nativeLabel: 'English' }]
const TRANSLATIONS = window.JobSenseiExtensionI18n?.strings || {}
const CHECK_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12 5 5L20 7"></path></svg>'

document.documentElement.dataset.surface = SURFACE

const elements = {
  brandMantra: document.getElementById('brandMantra'),
  captureTab: document.getElementById('captureTab'),
  aboutTab: document.getElementById('aboutTab'),
  capturePanel: document.getElementById('capturePanel'),
  aboutPanel: document.getElementById('aboutPanel'),
  pinBtn: document.getElementById('pinBtn'),
  closePanelBtn: document.getElementById('closePanelBtn'),
  themeBtn: document.getElementById('themeBtn'),
  visualsBtn: document.getElementById('visualsBtn'),
  languageTrigger: document.getElementById('languageTrigger'),
  languageMenu: document.getElementById('languageMenu'),
  languageHeading: document.getElementById('languageHeading'),
  languageOptions: document.getElementById('languageOptions'),
  languageNative: document.getElementById('languageNative'),
  languageLabel: document.getElementById('languageLabel'),
  captureNotice: document.getElementById('captureNotice'),
  companyLabel: document.getElementById('companyLabel'),
  roleLabel: document.getElementById('roleLabel'),
  urlLabel: document.getElementById('urlLabel'),
  jdLabel: document.getElementById('jdLabel'),
  company: document.getElementById('company'),
  role: document.getElementById('role'),
  url: document.getElementById('url'),
  jdText: document.getElementById('jdText'),
  status: document.getElementById('status'),
  sourceMeta: document.getElementById('sourceMeta'),
  lengthMeta: document.getElementById('lengthMeta'),
  refreshBtn: document.getElementById('refreshBtn'),
  sendBtn: document.getElementById('sendBtn'),
  aboutTitle: document.getElementById('aboutTitle'),
  aboutCopy: document.getElementById('aboutCopy'),
  feature1Title: document.getElementById('feature1Title'),
  feature1Body: document.getElementById('feature1Body'),
  feature2Title: document.getElementById('feature2Title'),
  feature2Body: document.getElementById('feature2Body'),
  feature3Title: document.getElementById('feature3Title'),
  feature3Body: document.getElementById('feature3Body'),
  dataSentSummary: document.getElementById('dataSentSummary'),
  dataSentBody: document.getElementById('dataSentBody'),
  openAppBtn: document.getElementById('openAppBtn'),
  backToCaptureBtn: document.getElementById('backToCaptureBtn'),
}

let prefs = { ...DEFAULT_PREFS }
let currentCaptureMeta = {}
let languageMenuOpen = false
let currentTabContext = { tabId: null, windowId: null }

document.addEventListener('DOMContentLoaded', async () => {
  elements.captureTab.addEventListener('click', () => showPanel('capture'))
  elements.aboutTab.addEventListener('click', () => showPanel('about'))
  elements.backToCaptureBtn.addEventListener('click', () => showPanel('capture'))
  elements.openAppBtn.addEventListener('click', openJobSensei)
  elements.pinBtn.addEventListener('click', openPinnedMode)
  elements.closePanelBtn.addEventListener('click', closeSidePanel)
  elements.jdText.addEventListener('input', updateMeta)
  elements.refreshBtn.addEventListener('click', () => captureCurrentPage({ userInitiated: true }))
  elements.sendBtn.addEventListener('click', handoffCapture)
  elements.themeBtn.addEventListener('click', () => {
    const idx = THEME_ORDER.indexOf(prefs.theme)
    updatePrefs({ theme: THEME_ORDER[(idx + 1) % THEME_ORDER.length] })
  })
  elements.visualsBtn.addEventListener('click', () => updatePrefs({ visuals: !prefs.visuals }))
  elements.languageTrigger.addEventListener('click', () => setLanguageMenuOpen(!languageMenuOpen))

  document.addEventListener('mousedown', event => {
    if (!languageMenuOpen) return
    if (elements.languageTrigger.contains(event.target) || elements.languageMenu.contains(event.target)) return
    setLanguageMenuOpen(false)
  })

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && languageMenuOpen) {
      setLanguageMenuOpen(false)
    }
  })

  await loadPrefs()
  await refreshCurrentTabContext()

  const pendingSelection = await consumePendingSelectionCapture()
  if (pendingSelection) {
    await captureCurrentPage({
      jdOverride: pendingSelection.jdText,
      fallbackPayload: pendingSelection,
      statusMessage: t('status.selectedLoaded'),
    })
    return
  }

  await captureCurrentPage()
})

function resolveLanguageCode(input) {
  const raw = String(input || '').trim()
  if (!raw) return 'en'
  const exact = LANGUAGE_OPTIONS.find(option => option.code.toLowerCase() === raw.toLowerCase())
  if (exact) return exact.code
  const base = raw.split('-')[0].toLowerCase()
  const match = LANGUAGE_OPTIONS.find(option => option.code.split('-')[0].toLowerCase() === base)
  return match?.code || 'en'
}

function getLanguageOption(code = prefs.language) {
  return LANGUAGE_OPTIONS.find(option => option.code === resolveLanguageCode(code)) || LANGUAGE_OPTIONS[0]
}

function getStrings() {
  return TRANSLATIONS[resolveLanguageCode(prefs.language)] || TRANSLATIONS.en
}

function t(path, replacements = {}) {
  const value = path.split('.').reduce((acc, key) => (acc && acc[key] !== undefined ? acc[key] : undefined), getStrings())
  if (typeof value !== 'string') return path
  return value.replace(/\{(\w+)\}/g, (_, key) => String(replacements[key] ?? ''))
}

function showPanel(panel) {
  const isCapture = panel === 'capture'
  elements.captureTab.classList.toggle('active', isCapture)
  elements.aboutTab.classList.toggle('active', !isCapture)
  elements.capturePanel.classList.toggle('hidden', !isCapture)
  elements.aboutPanel.classList.toggle('hidden', isCapture)
}

async function loadPrefs() {
  const saved = await storageGet(PREFS_KEY)
  const savedPrefs = saved?.[PREFS_KEY] || {}
  prefs = { ...DEFAULT_PREFS, ...savedPrefs }
  prefs.languageChosen = !!savedPrefs.languageChosen
  prefs.language = resolveLanguageCode(prefs.languageChosen ? prefs.language : 'en')
  if (prefs.theme === 'night') prefs.theme = 'dark'
  if (prefs.theme === 'neon') prefs.theme = 'myspace'
  if (!THEME_ORDER.includes(prefs.theme)) prefs.theme = DEFAULT_PREFS.theme
  applyPrefs()
}

async function updatePrefs(next) {
  const previousLanguage = prefs.language
  prefs = { ...prefs, ...next }
  if (Object.prototype.hasOwnProperty.call(next, 'language')) {
    prefs.languageChosen = true
  }
  prefs.language = resolveLanguageCode(prefs.language)
  applyPrefs()
  await storageSet({ [PREFS_KEY]: prefs })
  if (prefs.language !== previousLanguage) {
    chrome.runtime.sendMessage({ type: 'extension-language-changed', language: prefs.language }, () => void chrome.runtime.lastError)
  }
}

function applyPrefs() {
  document.documentElement.lang = prefs.language
  document.documentElement.dataset.theme = prefs.theme || DEFAULT_PREFS.theme
  document.documentElement.dataset.visuals = prefs.visuals ? 'on' : 'off'
  document.title = t('title')
  elements.visualsBtn.classList.toggle('active', !!prefs.visuals)
  elements.visualsBtn.title = prefs.visuals ? t('controls.visualsOn') : t('controls.visualsOff')
  elements.themeBtn.innerHTML = THEME_META[prefs.theme]?.icon || THEME_META.dark.icon
  elements.themeBtn.title = t('controls.themeCycle', { theme: t(`themes.${prefs.theme}`) })
  elements.pinBtn.title = t('buttons.pin')
  elements.closePanelBtn.title = t('buttons.closePanel')
  elements.languageTrigger.title = t('interfaceLanguage')
  elements.languageMenu.setAttribute('aria-label', t('interfaceLanguage'))
  applyTranslations()
  renderLanguageMenu()
  updateMeta()
  updateSourceMeta()
  updateSurfaceControls()
}

function applyTranslations() {
  elements.brandMantra.textContent = t('brandMantra')
  elements.captureTab.textContent = t('tabs.capture')
  elements.aboutTab.textContent = t('tabs.about')
  elements.captureNotice.textContent = t('notice')
  elements.companyLabel.textContent = t('labels.company')
  elements.roleLabel.textContent = t('labels.role')
  elements.urlLabel.textContent = t('labels.url')
  elements.jdLabel.textContent = t('labels.jd')
  elements.company.placeholder = t('placeholders.company')
  elements.role.placeholder = t('placeholders.role')
  elements.url.placeholder = t('placeholders.url')
  elements.jdText.placeholder = t('placeholders.jd')
  elements.refreshBtn.textContent = t('buttons.refresh')
  elements.sendBtn.textContent = t('buttons.send')
  elements.openAppBtn.textContent = t('buttons.open')
  elements.backToCaptureBtn.textContent = t('buttons.back')
  elements.aboutTitle.textContent = t('about.title')
  elements.aboutCopy.textContent = t('about.copy')
  elements.feature1Title.textContent = getStrings().features[0].title
  elements.feature1Body.textContent = getStrings().features[0].body
  elements.feature2Title.textContent = getStrings().features[1].title
  elements.feature2Body.textContent = getStrings().features[1].body
  elements.feature3Title.textContent = getStrings().features[2].title
  elements.feature3Body.textContent = getStrings().features[2].body
  elements.dataSentSummary.textContent = t('about.dataTitle')
  elements.dataSentBody.textContent = t('about.dataBody')
  elements.languageHeading.textContent = t('interfaceLanguage')
}

function renderLanguageMenu() {
  const selected = getLanguageOption()
  elements.languageNative.textContent = selected.nativeLabel
  elements.languageLabel.textContent = selected.label
  elements.languageOptions.innerHTML = ''

  LANGUAGE_OPTIONS.forEach(option => {
    const isSelected = option.code === prefs.language
    const button = document.createElement('button')
    button.type = 'button'
    button.className = `language-option${isSelected ? ' is-selected' : ''}`
    button.setAttribute('role', 'option')
    button.setAttribute('aria-selected', isSelected ? 'true' : 'false')
    button.innerHTML = `
      <span class="language-option-copy">
        <span class="language-option-native">${escapeHtml(option.nativeLabel)}</span>
        <span class="language-option-label">${escapeHtml(option.label)}</span>
      </span>
      <span class="language-check">${CHECK_ICON}</span>
    `
    button.addEventListener('click', async () => {
      setLanguageMenuOpen(false)
      await updatePrefs({ language: option.code })
    })
    elements.languageOptions.appendChild(button)
  })
}

function setLanguageMenuOpen(nextOpen) {
  languageMenuOpen = !!nextOpen
  elements.languageTrigger.setAttribute('aria-expanded', languageMenuOpen ? 'true' : 'false')
  elements.languageMenu.classList.toggle('hidden', !languageMenuOpen)
}

function updateSurfaceControls() {
  const isSidePanel = SURFACE === 'sidepanel'
  elements.pinBtn.classList.toggle('hidden', isSidePanel)
  elements.closePanelBtn.classList.toggle('hidden', !isSidePanel)
}

function closeSurface() {
  if (SURFACE === 'popup') {
    window.close()
  }
}

function openJobSensei() {
  chrome.tabs.create({ url: DEFAULT_APP_URL })
  closeSurface()
}

async function openPinnedMode() {
  const windowId = currentTabContext.windowId
  if (!windowId) {
    setStatus(t('status.noActiveTab'), 'error')
    return
  }

  setStatus(t('status.openingPinnedMode'))
  try {
    await chrome.sidePanel.open({ windowId })
    closeSurface()
  } catch (error) {
    setStatus(error?.message || t('status.couldNotDeliver'), 'error')
  }
}

async function closeSidePanel() {
  const tabContext = await ensureCurrentTabContext()
  if (!tabContext.tabId && !tabContext.windowId) {
    setStatus(t('status.noActiveTab'), 'error')
    return
  }

  try {
    await runtimeSendMessage({
      type: 'close-side-panel',
      tabId: tabContext.tabId,
      windowId: tabContext.windowId,
    })
  } catch (error) {
    setStatus(error?.message || t('status.couldNotDeliver'), 'error')
  }
}

async function consumePendingSelectionCapture() {
  const saved = await storageGet(PENDING_SELECTION_KEY)
  const payload = saved?.[PENDING_SELECTION_KEY] || null
  if (payload) await storageRemove(PENDING_SELECTION_KEY)
  return payload
}

async function captureCurrentPage(options = {}) {
  setStatus(t('status.readingCurrentPage'))
  const {
    jdOverride = '',
    fallbackPayload = null,
    statusMessage = t('status.captureRefreshed'),
    userInitiated = false,
  } = options

  try {
    const tab = await getTargetTab()
    if (!tab?.id) throw new Error(t('status.noActiveTab'))
    if (userInitiated) {
      await ensureHostAccessForCapture(tab.url)
    }

    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: readJobPage,
    })

    const payload = result?.result
    if (!payload) throw new Error(t('status.couldNotReadCurrentPage'))

    fillForm({
      ...payload,
      url: payload.url || tab.url,
      jdText: jdOverride || payload.jdText,
      source: jdOverride ? 'chrome-extension-selection' : payload.source,
      jdOnly: !!jdOverride,
      capturedAt: fallbackPayload?.capturedAt,
    })
    setStatus(statusMessage, 'success')
  } catch (error) {
    if (fallbackPayload) {
      fillForm(fallbackPayload)
      setStatus(statusMessage, 'success')
      return
    }
    setStatus(error.message || t('status.couldNotReadCurrentPage'), 'error')
  }
}

function fillForm(payload) {
  elements.company.value = payload.company || ''
  elements.role.value = payload.role || ''
  elements.url.value = payload.url || ''
  elements.jdText.value = payload.jdText || ''
  currentCaptureMeta = {
    source: payload.source || 'chrome-extension',
    pageTitle: payload.pageTitle || '',
    url: payload.url || '',
    capturedAt: payload.capturedAt,
    jdOnly: !!payload.jdOnly,
  }
  updateSourceMeta()
  updateMeta()
}

function updateSourceMeta() {
  const sourceLabel = currentCaptureMeta.source === 'chrome-extension-selection'
    ? t('meta.selectedText')
    : (currentCaptureMeta.pageTitle || t('meta.currentPage'))
  elements.sourceMeta.textContent = `${t('meta.sourcePrefix')}: ${sourceLabel}`
}

async function getTargetTab() {
  if (SURFACE === 'sidepanel' && SIDEPANEL_TAB_ID) {
    try {
      return await chrome.tabs.get(SIDEPANEL_TAB_ID)
    } catch {}
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  return tab || null
}

async function refreshCurrentTabContext() {
  const tab = await getTargetTab()
  currentTabContext = {
    tabId: tab?.id ?? SIDEPANEL_TAB_ID ?? null,
    windowId: tab?.windowId ?? SIDEPANEL_WINDOW_ID ?? null,
  }
  return currentTabContext
}

async function ensureCurrentTabContext() {
  if (currentTabContext.tabId) return currentTabContext
  return refreshCurrentTabContext()
}

function getOriginPattern(input) {
  try {
    const url = new URL(input || '')
    if (!/^https?:$/.test(url.protocol)) return ''
    return `${url.protocol}//${url.hostname}/*`
  } catch {
    return ''
  }
}

async function ensureHostAccessForCapture(tabUrl) {
  if (SURFACE !== 'sidepanel' || !chrome.permissions) return

  const originPattern = getOriginPattern(tabUrl)
  if (!originPattern) return

  const alreadyGranted = await chrome.permissions.contains({ origins: [originPattern] })
  if (alreadyGranted) return

  setStatus('Requesting access to this site...')
  const granted = await chrome.permissions.request({ origins: [originPattern] })
  if (!granted) {
    throw new Error('Site access was not granted for this page.')
  }
}

async function handoffCapture() {
  const payload = getFormPayload()

  if (!hasPayloadDetails(payload)) {
    setStatus(t('status.addJobDetail'), 'error')
    return
  }

  await sendToJobSensei(payload)
}

function getFormPayload() {
  return {
    company: elements.company.value.trim(),
    role: elements.role.value.trim(),
    url: elements.url.value.trim(),
    jdText: elements.jdText.value.trim(),
    source: currentCaptureMeta.source || 'chrome-extension',
    capturedAt: currentCaptureMeta.capturedAt || new Date().toISOString(),
    jdOnly: !!currentCaptureMeta.jdOnly,
  }
}

function hasPayloadDetails(payload) {
  return !!(payload.url || payload.jdText || payload.company || payload.role)
}

async function sendToJobSensei(payload) {
  setStatus(t('status.openingJobSensei'))

  chrome.runtime.sendMessage({ type: 'handoff-capture', payload, appUrl: DEFAULT_APP_URL }, response => {
    if (chrome.runtime.lastError) {
      setStatus(chrome.runtime.lastError.message, 'error')
      return
    }

    if (!response?.ok) {
      setStatus(response?.error || t('status.couldNotDeliver'), 'error')
      return
    }

    setStatus(t('status.sentToJobSensei'), 'success')
    closeSurface()
  })
}

function updateMeta() {
  elements.lengthMeta.textContent = t('meta.jdChars', { count: elements.jdText.value.trim().length })
}

function setStatus(message, tone = '') {
  elements.status.textContent = message
  elements.status.className = `status ${tone}`.trim()
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;')
}

function storageGet(key) {
  return new Promise(resolve => chrome.storage.local.get(key, resolve))
}

function storageSet(value) {
  return new Promise(resolve => chrome.storage.local.set(value, resolve))
}

function storageRemove(key) {
  return new Promise(resolve => chrome.storage.local.remove(key, resolve))
}

function runtimeSendMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, response => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message))
        return
      }

      if (response?.ok === false) {
        reject(new Error(response.error || t('status.couldNotDeliver')))
        return
      }

      resolve(response)
    })
  })
}

function readJobPage(selectedText = '') {
  function cleanText(value) {
    return (value || '').replace(/\s+/g, ' ').trim()
  }

  function cleanLines(value) {
    return (value || '')
      .split(/\r?\n/)
      .map(cleanText)
      .filter(Boolean)
  }

  function uniqueLines(lines) {
    const seen = new Set()
    return lines.filter(line => {
      const key = line.toLowerCase()
      if (seen.has(key)) return false
      seen.add(key)
      return true
    })
  }

  function htmlToText(value) {
    const div = document.createElement('div')
    div.innerHTML = value || ''
    div.querySelectorAll('br').forEach(br => br.replaceWith('\n'))
    div.querySelectorAll('p,li,h2,h3,h4').forEach(node => node.appendChild(document.createTextNode('\n')))
    return div.innerText || div.textContent || ''
  }

  function isVisible(node) {
    const rect = node.getBoundingClientRect?.()
    const style = window.getComputedStyle?.(node)
    return !!rect && rect.width > 0 && rect.height > 0 && style?.visibility !== 'hidden' && style?.display !== 'none'
  }

  function isGenericTitle(value) {
    return /^(careers?|jobs?|job openings?|open positions?|application|overview|for you|all jobs|job search|linkedin|jobs\.bg)$/i.test(cleanText(value))
  }

  function isBadRoleCandidate(value) {
    return /bookmark|message|menu|share|more_vert|subscribe|newsletter|apply|report|sign in|recommended|similar jobs|job alert/i.test(cleanText(value))
  }

  function isLikelyLocationLine(value) {
    const text = cleanText(value)
    if (!text) return false
    return /^(location_on|remote|hybrid|on-site|full-time|part-time|contract|temporary|internship)$/i.test(text)
      || /\bsofia\b|\bbulgaria\b|\bcity\b|\bremote\b|\bhybrid\b/i.test(text)
      || /(?:\d+\s+people clicked apply|\d+\s+applicants?)/i.test(text)
  }

  function isBadCompanyCandidate(value) {
    const text = cleanText(value)
    if (!text) return true
    return isGenericTitle(text)
      || isBadRoleCandidate(text)
      || isLikelyLocationLine(text)
      || /promoted by hirer|responses managed off linkedin|reposted|easy apply|save|show all|location_on/i.test(text)
  }

  function collectTextsFromSelectors(selectors) {
    const texts = []
    for (const selector of selectors) {
      const nodes = Array.from(document.querySelectorAll(selector))
      for (const node of nodes) {
        if (!isVisible(node)) continue
        const text = cleanText(node.innerText || node.textContent || '')
        if (text.length >= 3) texts.push(text)
      }
    }
    return texts
  }

  function scoreRoleCandidate(value) {
    const text = cleanText(value)
    if (!text || text.length < 4 || text.length > 120 || isGenericTitle(text) || isBadRoleCandidate(text)) return -100
    let score = 0
    if (/analyst|expert|engineer|developer|manager|specialist|designer|consultant|director|lead|associate|coordinator|officer|architect|scientist|administrator|accountant|recruiter|intern|payments?|kyc|aml|risk|fraud|compliance|product|operations|sales|marketing|finance|support/i.test(text)) score += 8
    if (/[\u0400-\u04FF]/.test(text) && text.split(/\s+/).length >= 2) score += 5
    if (/&|\/|\b[A-Z]{2,}\b/.test(text)) score += 2
    if (/remote|hybrid|sofia|bulgaria|fully/i.test(text)) score += 1
    if (text.split(/\s+/).length >= 2 && text.split(/\s+/).length <= 10) score += 2
    if (/[.!?]\s/.test(text)) score -= 5
    return score
  }

  function bestRoleCandidate(candidates) {
    return candidates
      .map(text => ({ text: cleanText(text), score: scoreRoleCandidate(text) }))
      .filter(item => item.text && item.score > -100)
      .sort((a, b) => b.score - a.score)[0]?.text || ''
  }

  function roleFromPageTitle(title) {
    const parts = splitTitle(title)
    const jobsBgPart = title.match(/jobs\.bg\s*-\s*([^,|\u2013\u2014]+)/i)?.[1]
    return bestRoleCandidate([jobsBgPart, ...parts])
  }

  function splitTitle(title) {
    return cleanText(title)
      .split(/\s+(?:[|\-]|\u2013|\u2014|\u00b7)\s+/)
      .map(cleanText)
      .filter(Boolean)
      .filter(part => !isGenericTitle(part))
  }

  function titleize(value) {
    return cleanText(value)
      .split(/\s+/)
      .filter(Boolean)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ')
  }

  function textFromSelectors(selectors, rejectPattern = null) {
    for (const selector of selectors) {
      const nodes = Array.from(document.querySelectorAll(selector))
      for (const node of nodes) {
        if (!isVisible(node)) continue
        const text = cleanText(node.innerText || node.textContent || '')
        if (text.length < 3 || isGenericTitle(text)) continue
        if (rejectPattern && rejectPattern.test(text)) continue
        return text
      }
    }
    return ''
  }

  function metaContent(selectors) {
    for (const selector of selectors) {
      const value = cleanText(document.querySelector(selector)?.content || '')
      if (value) return value
    }
    return ''
  }

  function readJsonLdJobPosting() {
    const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'))
    const postings = []

    function visit(value) {
      if (!value) return
      if (Array.isArray(value)) {
        value.forEach(visit)
        return
      }
      if (typeof value !== 'object') return
      if (Array.isArray(value['@graph'])) value['@graph'].forEach(visit)

      const type = value['@type']
      const types = Array.isArray(type) ? type : [type]
      if (types.some(item => String(item).toLowerCase() === 'jobposting')) {
        postings.push(value)
      }
    }

    for (const script of scripts) {
      try {
        visit(JSON.parse(script.textContent || '{}'))
      } catch {}
    }

    const posting = postings[0] || null
    if (!posting) return null
    const organization = posting.hiringOrganization || posting.organization || {}

    return {
      company: cleanText(typeof organization === 'string' ? organization : organization.name),
      role: cleanText(posting.title),
      jdText: cleanText(htmlToText(posting.description || '')),
    }
  }

  function collectNodesFromSelectors(selectors) {
    const nodes = []
    const seen = new Set()
    for (const selector of selectors) {
      for (const node of Array.from(document.querySelectorAll(selector))) {
        if (seen.has(node)) continue
        seen.add(node)
        nodes.push(node)
      }
    }
    return nodes
  }

  function countJdKeywords(text) {
    const lowered = cleanText(text).toLowerCase()
    return (lowered.match(/responsibilities|requirements|qualifications|skills|experience|about the role|about you|what you will|what you'll|we offer|benefits|duties|knowledge|candidate|tasks|\u0438\u0437\u0438\u0441\u043a\u0432\u0430\u043d\u0438\u044f|\u043e\u0442\u0433\u043e\u0432\u043e\u0440\u043d\u043e\u0441\u0442\u0438|\u043a\u0432\u0430\u043b\u0438\u0444\u0438\u043a\u0430\u0446\u0438\u0438|\u0443\u043c\u0435\u043d\u0438\u044f|\u043f\u0440\u0435\u0434\u043b\u0430\u0433\u0430\u043c\u0435|\u043e\u043f\u0438\u0441\u0430\u043d\u0438\u0435/gi) || []).length
  }

  function scoreJdCandidate(text, node, selectorIndex = 0) {
    const compact = cleanText(text)
    if (compact.length < 220) return -100

    const lowered = compact.toLowerCase()
    const keywordMatches = countJdKeywords(compact)
    const noisyMatches = (lowered.match(/apply now|easy apply|sign in|create alert|recommended jobs|similar jobs|people also viewed|cookie|privacy policy|terms of use|save job|share this job|report this job/g) || []).length
    const lengthScore = Math.min(compact.length / 120, 55)
    const mainBoost = node?.closest?.('main, article, [role="main"]') ? 8 : 0
    const selectorBoost = Math.max(0, 20 - selectorIndex)
    const topCardPenalty = /promoted by hirer|responses managed off linkedin|people clicked apply|reposted|save job/i.test(lowered) ? 18 : 0

    return lengthScore + (keywordMatches * 8) + mainBoost + selectorBoost - (noisyMatches * 12) - topCardPenalty - (compact.length > 25000 ? 18 : 0)
  }

  function bestJdFromSelectors(selectors) {
    let best = { text: '', score: -100 }
    selectors.forEach((selector, index) => {
      for (const node of Array.from(document.querySelectorAll(selector))) {
        if (!isVisible(node)) continue
        const text = node.innerText || node.textContent || ''
        const score = scoreJdCandidate(text, node, index)
        if (score > best.score) best = { text, score }
      }
    })
    return best.text
  }

  function findTextNearHeading(patterns) {
    const headings = Array.from(document.querySelectorAll('h1, h2, h3, h4, strong, span, div, p'))
    let best = ''
    let bestScore = -100

    for (const heading of headings) {
      if (!isVisible(heading)) continue
      const headingText = cleanText(heading.innerText || heading.textContent || '')
      if (!headingText || headingText.length > 80) continue
      if (!patterns.some(pattern => pattern.test(headingText))) continue

      const candidateNodes = [
        heading.nextElementSibling,
        heading.parentElement?.nextElementSibling,
        heading.closest('section, article, [class*="description" i], [class*="details" i], [class*="content" i]'),
        heading.parentElement,
      ].filter(Boolean)

      const seen = new Set()
      for (const node of candidateNodes) {
        if (seen.has(node) || !isVisible(node)) continue
        seen.add(node)
        const text = node.innerText || node.textContent || ''
        const score = scoreJdCandidate(text, node, 0) + (countJdKeywords(text) * 10)
        if (score > bestScore) {
          best = text
          bestScore = score
        }
      }
    }

    return best
  }

  function normalizeJdText(rawText) {
    const noiseLine = /^(apply|apply now|easy apply|save|saved|share|copy link|report|sign in|join now|follow|message|more|show more|show less|see more|job alert|recommended jobs|similar jobs|people also viewed|about linkedin|cookie|privacy policy|terms of use|back to jobs)$/i
    let lines = uniqueLines(cleanLines(rawText))
      .filter(line => line.length > 1)
      .filter(line => !noiseLine.test(line))
      .filter(line => !/^(bookmark|message|menu|share|more_vert)$/i.test(line))
      .filter(line => !/^\d+\s+(applicants?|views?)$/i.test(line))
      .filter(line => !/promoted by hirer|responses managed off linkedin|reposted \d+|over \d+ people clicked apply/i.test(line))

    while (lines.length > 3 && countJdKeywords(lines.slice(0, 4).join(' ')) === 0 && lines[0].length < 120) {
      lines = lines.slice(1)
    }

    return lines.join('\n').slice(0, 12000)
  }

  function companyFromVisibleLines(lines, role) {
    const roleKey = cleanText(role).toLowerCase()
    const start = roleKey ? lines.findIndex(line => cleanText(line).toLowerCase() === roleKey) : -1
    const before = start > 0 ? lines.slice(Math.max(0, start - 4), start).reverse() : []
    const after = start >= 0 ? lines.slice(start + 1, start + 6) : []
    const candidates = [...before, ...after, ...lines.slice(0, 20)]
      .filter(line => line.length >= 2 && line.length <= 90)
      .filter(line => !isBadCompanyCandidate(line))
      .filter(line => cleanText(line).toLowerCase() !== roleKey)
      .filter(line => !/^(open to work|looking for talent)$/i.test(line))

    return candidates[0] || ''
  }

  function splitJobsBgRoleAndCompany(rawRole, fallbackCompany) {
    const text = cleanText(rawRole)
    if (!/jobs\.bg/i.test(hostname) || !text.includes(',')) {
      return { role: text, company: fallbackCompany }
    }

    const parts = text.split(',').map(cleanText).filter(Boolean)
    if (parts.length < 2) return { role: text, company: fallbackCompany }

    const trailing = parts.slice(1).join(' ')
    if (/(eood|ood|ad|ltd|gmbh|inc|llc|\u0435\u043e\u043e\u0434|\u043e\u043e\u0434|\u0430\u0434)/i.test(trailing) || /[\u0400-\u04FF]{3,}/.test(trailing)) {
      return {
        role: parts[0],
        company: cleanText(fallbackCompany || trailing),
      }
    }

    return { role: text, company: fallbackCompany }
  }

  const pageTitle = cleanText(document.title)
  const titleParts = splitTitle(pageTitle)
  const visibleLines = cleanLines(document.body?.innerText || '')
  const hostname = window.location.hostname.replace(/^www\./i, '')
  const hostFallback = titleize(hostname.split('.')[0].replace(/[-_]+/g, ' '))
  const jsonLd = readJsonLdJobPosting()

  const metaTitle = metaContent([
    'meta[property="og:title"]',
    'meta[name="twitter:title"]',
    'meta[name="title"]',
  ])

  const roleSelectors = [
    '[class*="jobs-unified-top-card__job-title" i]',
    '[class*="job-details-jobs-unified-top-card__job-title" i]',
    '[class*="topcard__title" i]',
    '[data-testid*="job-title" i]',
    '[data-automation-id*="job-title" i]',
    '[data-qa*="job-title" i]',
    '[itemprop="title"]',
    '[class*="job-title" i]',
    '[class*="jobTitle" i]',
    '[class*="position-title" i]',
    '[class*="vacancy-title" i]',
    'h1',
    'h2',
    '[data-testid*="title" i]',
    '[class*="headline" i]',
  ]

  const role = jsonLd?.role || bestRoleCandidate([
    ...collectTextsFromSelectors(roleSelectors),
    roleFromPageTitle(pageTitle),
    metaTitle,
    ...titleParts,
    ...visibleLines.slice(0, 45),
  ])

  const companySelectors = [
    '[class*="jobs-unified-top-card__company-name" i]',
    '[class*="job-details-jobs-unified-top-card__company-name" i]',
    '[class*="jobs-unified-top-card__company-name"] a',
    '[class*="job-details-jobs-unified-top-card__company-name"] a',
    '[class*="topcard__org-name" i]',
    '[data-testid*="company" i]',
    '[data-automation-id*="company" i]',
    '[data-qa*="company" i]',
    '[itemprop="hiringOrganization"]',
    '[class*="company-name" i]',
    '[class*="employer-name" i]',
    'a[href*="/company/"]',
    '[data-company]',
  ]

  const metaSiteName = metaContent([
    'meta[property="og:site_name"]',
    'meta[name="application-name"]',
  ])
  const jobsBgCompany = /jobs\.bg/i.test(hostname)
    ? cleanText(pageTitle.match(/\s(?:from|at)\s([^|\u2013\u2014]+)/i)?.[1] || '')
    : ''
  let company = jsonLd?.company
    || textFromSelectors(companySelectors, /promoted by hirer|responses managed off linkedin|location_on|reposted/i)
    || jobsBgCompany
    || companyFromVisibleLines(visibleLines, role)
    || titleParts.find(part => part !== role && !/jobs\.bg|linkedin|careers?|job search/i.test(part))
    || (!/linkedin|jobs\.bg/i.test(hostname) ? metaSiteName : '')
    || hostFallback

  const jobsBgParsed = splitJobsBgRoleAndCompany(role, company)
  const finalRole = jobsBgParsed.role || role
  company = jobsBgParsed.company || company

  if (/linkedin/i.test(hostname) && company.includes('\n')) {
    company = cleanLines(company)[0] || company
  }

  const jdSelectors = [
    '#job-details',
    '[class*="jobs-box__job-description" i]',
    '[class*="jobs-description__content" i]',
    '[class*="jobs-box__html-content" i]',
    '[class*="jobs-description-content" i]',
    '[class*="show-more-less-html" i]',
    '[data-testid*="job-description" i]',
    '[data-automation-id*="job-description" i]',
    '[data-qa*="job-description" i]',
    '[itemprop="description"]',
    '.job-description',
    '#job-description',
    '[class*="job-description" i]',
    '[class*="jobDescription" i]',
    '[class*="vacancy-description" i]',
    '[class*="posting-description" i]',
    '[class*="description" i]',
    '[data-testid*="description" i]',
    'article',
    'main',
    '[role="main"]',
  ]

  let jdText = selectedText
  if (!jdText && cleanText(jsonLd?.jdText).length >= 350) jdText = jsonLd.jdText
  if (!jdText) {
    jdText = findTextNearHeading([
      /^about the job$/i,
      /^job description$/i,
      /^description$/i,
      /^\u043e\u043f\u0438\u0441\u0430\u043d\u0438\u0435/i,
      /^\u0438\u0437\u0438\u0441\u043a\u0432\u0430\u043d\u0438\u044f/i,
      /^\u043e\u0442\u0433\u043e\u0432\u043e\u0440\u043d\u043e\u0441\u0442\u0438/i,
    ]) || bestJdFromSelectors(jdSelectors)
  }
  if ((cleanText(jdText).length < 400 || countJdKeywords(jdText) === 0) && !selectedText) {
    const mainText = collectNodesFromSelectors(['main', 'article', '[role="main"]'])
      .map(node => node.innerText || node.textContent || '')
      .sort((a, b) => cleanText(b).length - cleanText(a).length)[0]
    jdText = mainText || document.body?.innerText || ''
  }
  jdText = normalizeJdText(jdText)

  return {
    company: cleanText(company),
    role: cleanText(finalRole),
    jdText,
    url: window.location.href,
    pageTitle,
    source: selectedText ? 'chrome-extension-selection' : 'chrome-extension',
  }
}
