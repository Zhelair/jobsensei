const BRIDGE_KEY = 'jobsensei_extension_capture_v1'
const PENDING_SELECTION_KEY = 'jobsensei_pending_selection_capture_v1'
const PREFS_KEY = 'jobsensei_extension_prefs_v1'
const SIDEPANEL_STATE_KEY = 'jobsensei_sidepanel_open_tabs_v1'
const SELECTION_MENU_ID = 'jobsensei-copy-jd-selection'
const MENU_TITLES = {
  en: 'Copy selected JD to JobSensei',
  de: 'Ausgewählten JD-Text nach JobSensei kopieren',
  bg: 'Копирай избрания JD текст в JobSensei',
  ru: 'Скопировать выделенный JD-текст в JobSensei',
  'es-ES': 'Copiar el texto JD seleccionado a JobSensei',
  fr: 'Copier le texte JD sélectionné vers JobSensei',
  it: 'Copia il testo JD selezionato in JobSensei',
  pl: 'Skopiuj zaznaczony tekst JD do JobSensei',
  'pt-BR': 'Copiar o texto JD selecionado para o JobSensei',
}

chrome.runtime.onInstalled.addListener(() => {
  void resetSidePanelState()
  void createContextMenus()
})
chrome.runtime.onStartup?.addListener(() => {
  void resetSidePanelState()
  void createContextMenus()
})

if (chrome.sidePanel?.onOpened) {
  chrome.sidePanel.onOpened.addListener(info => {
    if (typeof info.tabId === 'number') {
      void setSidePanelOpen(info.tabId, true)
    }
  })
}

if (chrome.sidePanel?.onClosed) {
  chrome.sidePanel.onClosed.addListener(info => {
    if (typeof info.tabId === 'number') {
      void setSidePanelOpen(info.tabId, false)
    }
  })
}

chrome.tabs.onRemoved.addListener(tabId => {
  void setSidePanelOpen(tabId, false)
})

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== SELECTION_MENU_ID) return

  handleSelectionCapture(info, tab).catch(error => {
    console.error('JobSensei selection capture failed:', error)
  })
})

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'handoff-capture') {
    handleCaptureHandoff(message.payload, message.appUrl)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: error.message }))

    return true
  }

  if (message?.type === 'open-side-panel') {
    handleOpenSidePanel(message.tabId, message.windowId)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: error.message }))

    return true
  }

  if (message?.type === 'close-side-panel') {
    handleCloseSidePanel(message.tabId, message.windowId)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: error.message }))

    return true
  }

  if (message?.type === 'get-side-panel-state') {
    getSidePanelState(message.tabId)
      .then(open => sendResponse({ ok: true, open }))
      .catch(error => sendResponse({ ok: false, error: error.message }))

    return true
  }

  if (message?.type === 'extension-language-changed') {
    createContextMenus(message.language)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: error.message }))

    return true
  }

  return undefined
})

async function handleCaptureHandoff(payload, appUrl) {
  const targetUrl = normalizeAppUrl(appUrl)
  let appTab = await findExistingAppTab(targetUrl)

  if (appTab) {
    const shouldReload = normalizeAppUrl(appTab.url || '') === targetUrl
    appTab = await chrome.tabs.update(appTab.id, shouldReload ? { active: true } : { active: true, url: targetUrl })
    if (shouldReload) {
      await chrome.tabs.reload(appTab.id)
    }
  } else {
    appTab = await chrome.tabs.create({ url: targetUrl, active: true })
  }

  if (appTab.windowId) {
    await chrome.windows.update(appTab.windowId, { focused: true })
  }

  await waitForTabReady(appTab.id)
  const delivered = await deliverCaptureToTab(appTab.id, payload)
  if (!delivered.ok) {
    const fallbackTab = await chrome.tabs.create({ url: targetUrl, active: true })
    if (fallbackTab.windowId) {
      await chrome.windows.update(fallbackTab.windowId, { focused: true })
    }
    await waitForTabReady(fallbackTab.id)
    const retry = await deliverCaptureToTab(fallbackTab.id, payload)
    if (!retry.ok) {
      throw new Error(retry.error || delivered.error || 'Could not deliver the capture to JobSensei.')
    }
  }
}

async function deliverCaptureToTab(tabId, payload) {
  const [injection] = await chrome.scripting.executeScript({
    target: { tabId },
    func: deliverCaptureToPage,
    args: [BRIDGE_KEY, payload],
  })

  if (injection?.result?.error) {
    return { ok: false, error: injection.result.error }
  }

  return { ok: true }
}

function normalizeAppUrl(input) {
  const trimmed = (input || '').trim() || 'https://jobsensei.app'
  const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`
  const url = new URL(withProtocol)
  const path = url.pathname === '/' ? '' : url.pathname
  return `${url.origin}${path}${url.hash || '#applications'}`
}

async function findExistingAppTab(targetUrl) {
  const origin = new URL(targetUrl).origin
  const tabs = await chrome.tabs.query({})
  return tabs.find(tab => tab.url && tab.url.startsWith(origin)) || null
}

function waitForTabReady(tabId) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(handleUpdated)
      reject(new Error('Timed out waiting for JobSensei to open.'))
    }, 15000)

    function handleUpdated(updatedTabId, info) {
      if (updatedTabId !== tabId || info.status !== 'complete') return
      clearTimeout(timeout)
      chrome.tabs.onUpdated.removeListener(handleUpdated)
      resolve()
    }

    chrome.tabs.get(tabId, tab => {
      if (chrome.runtime.lastError) {
        clearTimeout(timeout)
        chrome.tabs.onUpdated.removeListener(handleUpdated)
        reject(new Error(chrome.runtime.lastError.message))
        return
      }

      if (tab?.status === 'complete') {
        clearTimeout(timeout)
        resolve()
        return
      }

      chrome.tabs.onUpdated.addListener(handleUpdated)
    })
  })
}

function deliverCaptureToPage(storageKey, payload) {
  try {
    localStorage.setItem(storageKey, JSON.stringify(payload))
    window.dispatchEvent(new CustomEvent('jobsensei-extension-capture', { detail: payload }))
    return { ok: true }
  } catch (error) {
    return { error: error.message }
  }
}

async function createContextMenus(languageOverride = '') {
  const title = await getContextMenuTitle(languageOverride)
  chrome.contextMenus.remove(SELECTION_MENU_ID, () => {
    void chrome.runtime.lastError
    chrome.contextMenus.create({
      id: SELECTION_MENU_ID,
      title,
      contexts: ['selection'],
    })
  })
}

async function handleSelectionCapture(info, tab) {
  if (!tab?.id) throw new Error('No active tab available.')
  const selectedText = (info.selectionText || '').trim()
  if (!selectedText) throw new Error('Select job description text first.')

  const payload = {
    company: '',
    role: '',
    url: tab.url || '',
    jdText: selectedText,
    pageTitle: tab.title || '',
    source: 'chrome-extension-selection',
    jdOnly: true,
  }

  await chrome.storage.local.set({
    [PENDING_SELECTION_KEY]: {
      ...payload,
      source: 'chrome-extension-selection',
      capturedAt: new Date().toISOString(),
    },
  })

  if (tab.windowId) {
    await chrome.windows.update(tab.windowId, { focused: true })
  }

  if (await getSidePanelState(tab.id)) {
    try {
      await chrome.sidePanel.open({ tabId: tab.id })
      return
    } catch {}
  }

  try {
    await chrome.action.openPopup()
  } catch {
    await chrome.tabs.create({ url: chrome.runtime.getURL('popup.html'), active: true })
  }
}

async function handleOpenSidePanel(tabId, windowId) {
  if (!tabId || !chrome.sidePanel) {
    throw new Error('Side panel is not available in this browser.')
  }
  await chrome.sidePanel.setOptions({
    tabId,
    path: buildSidePanelPath(tabId, windowId),
    enabled: true,
  })
  await chrome.sidePanel.open({ tabId })
  await setSidePanelOpen(tabId, true)
  if (windowId) {
    await chrome.windows.update(windowId, { focused: true })
  }
}

async function handleCloseSidePanel(tabId, windowId) {
  if ((!tabId && !windowId) || !chrome.sidePanel) {
    throw new Error('Side panel is not available in this browser.')
  }

  let lastError = null
  if (chrome.sidePanel.close) {
    if (tabId) {
      try {
        await chrome.sidePanel.close({ tabId })
      } catch (error) {
        lastError = error
      }
    }

    if (windowId) {
      try {
        await chrome.sidePanel.close({ windowId })
        lastError = null
      } catch (error) {
        if (!lastError) lastError = error
      }
    }
  } else if (tabId) {
    try {
      await chrome.sidePanel.setOptions({
        tabId,
        enabled: false,
      })
      lastError = null
    } catch (error) {
      lastError = error
    }
  }

  if (tabId && chrome.sidePanel.setOptions) {
    try {
      await chrome.sidePanel.setOptions({
        tabId,
        path: buildSidePanelPath(tabId, windowId),
        enabled: false,
      })
    } catch (error) {
      if (!lastError) lastError = error
    }
  }

  if (tabId) {
    await setSidePanelOpen(tabId, false)
  }

  if (lastError) {
    const message = String(lastError.message || '')
    if (/No active tab-specific side panel/i.test(message)) {
      return
    }
    if (/No active side panel/i.test(message)) {
      return
    }
    throw lastError
  }
}

function buildSidePanelPath(tabId, windowId) {
  const params = new URLSearchParams({ surface: 'sidepanel' })
  if (tabId) {
    params.set('tabId', String(tabId))
  }
  if (windowId) {
    params.set('windowId', String(windowId))
  }
  return `popup.html?${params.toString()}`
}

function resolveLanguageCode(input) {
  const raw = String(input || '').trim()
  if (!raw) return 'en'
  const exact = Object.keys(MENU_TITLES).find(code => code.toLowerCase() === raw.toLowerCase())
  if (exact) return exact
  const base = raw.split('-')[0].toLowerCase()
  return Object.keys(MENU_TITLES).find(code => code.split('-')[0].toLowerCase() === base) || 'en'
}

async function getContextMenuTitle(languageOverride = '') {
  const safeLanguage = resolveLanguageCode(
    languageOverride
    || (await chrome.storage.local.get(PREFS_KEY))?.[PREFS_KEY]?.language
    || chrome.i18n.getUILanguage()
    || 'en'
  )
  return MENU_TITLES[safeLanguage] || MENU_TITLES.en
}

async function resetSidePanelState() {
  await chrome.storage.local.set({ [SIDEPANEL_STATE_KEY]: {} })
}

async function getSidePanelState(tabId) {
  if (typeof tabId !== 'number') return false
  const saved = await chrome.storage.local.get(SIDEPANEL_STATE_KEY)
  return !!saved?.[SIDEPANEL_STATE_KEY]?.[String(tabId)]
}

async function setSidePanelOpen(tabId, open) {
  if (typeof tabId !== 'number') return
  const saved = await chrome.storage.local.get(SIDEPANEL_STATE_KEY)
  const nextState = { ...(saved?.[SIDEPANEL_STATE_KEY] || {}) }
  if (open) {
    nextState[String(tabId)] = true
  } else {
    delete nextState[String(tabId)]
  }
  await chrome.storage.local.set({ [SIDEPANEL_STATE_KEY]: nextState })
}

function extractSelectionCaptureFromPage(selectedText) {
  function cleanText(value) {
    return (value || '').replace(/\s+/g, ' ').trim()
  }

  function cleanLines(value) {
    return (value || '')
      .split(/\r?\n/)
      .map(cleanText)
      .filter(Boolean)
  }

  function isVisible(node) {
    const rect = node.getBoundingClientRect?.()
    const style = window.getComputedStyle?.(node)
    return !!rect && rect.width > 0 && rect.height > 0 && style?.visibility !== 'hidden' && style?.display !== 'none'
  }

  function isGenericTitle(value) {
    return /^(careers?|jobs?|job openings?|open positions?|application|overview|for you|all jobs)$/i.test(cleanText(value))
  }

  function titleize(value) {
    return cleanText(value)
      .split(/\s+/)
      .filter(Boolean)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ')
  }

  function collectTexts(selectors) {
    const texts = []
    for (const selector of selectors) {
      const nodes = Array.from(document.querySelectorAll(selector))
      for (const node of nodes) {
        if (!isVisible(node)) continue
        const text = cleanText(node.innerText || node.textContent || '')
        if (text.length >= 3) texts.push(text)
      }
    }
    return texts
  }

  function scoreRoleCandidate(value) {
    const text = cleanText(value)
    if (!text || text.length < 4 || text.length > 120 || isGenericTitle(text)) return -100
    if (/bookmark|message|menu|share|more_vert|subscribe|newsletter|apply|report/i.test(text)) return -100
    let score = 0
    if (/analyst|expert|engineer|developer|manager|specialist|designer|consultant|director|lead|associate|coordinator|officer|architect|scientist|administrator|accountant|recruiter|intern|payments?|kyc|aml|risk|fraud|compliance/i.test(text)) score += 8
    if (/&|\/|\b[A-Z]{2,}\b/.test(text)) score += 2
    if (text.split(/\s+/).length >= 2 && text.split(/\s+/).length <= 10) score += 2
    return score
  }

  function bestRoleCandidate(candidates) {
    return candidates
      .map(text => ({ text: cleanText(text), score: scoreRoleCandidate(text) }))
      .filter(item => item.text && item.score > -100)
      .sort((a, b) => b.score - a.score)[0]?.text || ''
  }

  function textFromSelectors(selectors) {
    for (const text of collectTexts(selectors)) {
      if (!isGenericTitle(text)) return text
    }
    return ''
  }

  const pageTitle = cleanText(document.title)
  const titleParts = pageTitle.split(/\s+[|\-–—]\s+/).map(cleanText).filter(Boolean)
  const visibleLines = cleanLines(document.body?.innerText || '')
  const role = bestRoleCandidate([
    ...collectTexts([
      '[data-testid*="job-title" i]',
      '[data-automation-id*="job-title" i]',
      '[class*="job-title" i]',
      '[class*="jobTitle" i]',
      'h1',
      'h2',
    ]),
    ...titleParts,
    ...visibleLines.slice(0, 35),
  ])

  const hostname = window.location.hostname.replace(/^www\./i, '')
  const hostFallback = titleize(hostname.split('.')[0].replace(/[-_]+/g, ' '))
  const company = textFromSelectors([
    '[data-testid*="company" i]',
    '[data-automation-id*="company" i]',
    '[class*="company" i]',
    '[class*="employer" i]',
    '[data-company]',
  ]) || titleParts.find(part => part !== role && !isGenericTitle(part)) || cleanText(document.querySelector('meta[property="og:site_name"]')?.content || '') || hostFallback

  return {
    company,
    role,
    jdText: cleanLines(selectedText).join(' ').slice(0, 12000),
    url: window.location.href,
    pageTitle,
    source: 'chrome-extension-selection',
  }
}
